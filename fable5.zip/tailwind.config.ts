import type { Config } from "tailwindcss";

/**
 * Design system LaunchPilot — inspiré de Linear, Notion et Stripe.
 * Dominantes : bleu marine (navy) et blanc.
 */
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        navy: {
          50: "#f0f4fa",
          100: "#dce6f5",
          200: "#bdd0ea",
          300: "#92b1da",
          400: "#5f8ac5",
          500: "#3d6cb0",
          600: "#2d5494",
          700: "#264478",
          800: "#233b64",
          900: "#1b2c4e",
          950: "#0e1830",
        },
        surface: {
          DEFAULT: "#ffffff",
          subtle: "#f8fafc",
          muted: "#f1f5f9",
        },
      },
      fontFamily: {
        sans: ["var(--font-inter)", "system-ui", "sans-serif"],
      },
      boxShadow: {
        card: "0 1px 2px rgba(14, 24, 48, 0.06), 0 1px 3px rgba(14, 24, 48, 0.08)",
        "card-hover":
          "0 4px 12px rgba(14, 24, 48, 0.10), 0 2px 4px rgba(14, 24, 48, 0.06)",
      },
      borderRadius: {
        xl: "0.875rem",
      },
      keyframes: {
        "fade-up": {
          from: { opacity: "0", transform: "translateY(8px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.35s ease-out both",
      },
    },
  },
  plugins: [],
};

export default config;
