"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Rocket,
  LayoutDashboard,
  LayoutTemplate,
  CreditCard,
  LogOut,
} from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import type { PlanType } from "@/types/database";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/templates", label: "Templates", icon: LayoutTemplate },
  { href: "/settings/billing", label: "Abonnement", icon: CreditCard },
];

const PLAN_LABELS: Record<PlanType, string> = {
  free: "Gratuit",
  pro: "Pro",
  unlimited: "Unlimited",
};

export function Sidebar({ email, plan }: { email: string; plan: PlanType }) {
  const pathname = usePathname();
  const router = useRouter();

  async function handleSignOut() {
    await createClient().auth.signOut();
    router.push("/");
    router.refresh();
  }

  return (
    <aside className="flex h-screen w-64 shrink-0 flex-col border-r border-navy-100 bg-white">
      <div className="flex h-16 items-center gap-2 border-b border-navy-100 px-6">
        <Rocket className="h-5 w-5 text-navy-700" />
        <span className="font-semibold text-navy-950">LaunchPilot</span>
      </div>

      <nav className="flex-1 space-y-1 p-4">
        {NAV.map((item) => {
          const active =
            pathname === item.href || pathname.startsWith(item.href + "/");
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                active
                  ? "bg-navy-900 text-white"
                  : "text-navy-600 hover:bg-navy-50 hover:text-navy-950"
              )}
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-navy-100 p-4">
        <div className="mb-3 flex items-center justify-between gap-2">
          <span className="truncate text-sm text-navy-600">{email}</span>
          <Badge variant={plan === "free" ? "default" : "navy"}>
            {PLAN_LABELS[plan]}
          </Badge>
        </div>
        <button
          onClick={handleSignOut}
          className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-navy-500 transition-colors hover:bg-navy-50 hover:text-navy-950"
        >
          <LogOut className="h-4 w-4" />
          Déconnexion
        </button>
      </div>
    </aside>
  );
}
