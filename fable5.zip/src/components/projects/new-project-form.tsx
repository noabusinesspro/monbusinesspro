"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { PROJECT_TYPES } from "@/lib/project-types";
import { Button } from "@/components/ui/button";
import { Input, Label, Textarea } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import type { ProjectType } from "@/types/database";

export function NewProjectForm({
  initialType = "saas",
}: {
  initialType?: ProjectType;
}) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [type, setType] = useState<ProjectType>(initialType);
  const [description, setDescription] = useState("");
  const [launchDate, setLaunchDate] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          type,
          description: description || undefined,
          launch_date: launchDate || null,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Erreur de création");
      router.push(`/projects/${data.project.id}`);
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur inattendue");
      setLoading(false);
    }
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-6 rounded-xl border border-navy-100 bg-white p-8 shadow-card"
    >
      <div>
        <Label htmlFor="name">Nom du projet</Label>
        <Input
          id="name"
          required
          maxLength={120}
          placeholder="Ex. : Notion Tracker, Ma formation copywriting…"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </div>

      <div>
        <Label>Type de projet</Label>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {PROJECT_TYPES.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setType(t.id)}
              className={cn(
                "rounded-lg border p-3 text-left transition-colors",
                type === t.id
                  ? "border-navy-700 bg-navy-50 ring-1 ring-navy-700"
                  : "border-navy-100 hover:border-navy-300"
              )}
            >
              <div className="text-xl">{t.emoji}</div>
              <div className="mt-1 text-sm font-medium text-navy-900">
                {t.label}
              </div>
            </button>
          ))}
        </div>
      </div>

      <div>
        <Label htmlFor="launch_date">Date de lancement (optionnel)</Label>
        <Input
          id="launch_date"
          type="date"
          value={launchDate}
          onChange={(e) => setLaunchDate(e.target.value)}
        />
      </div>

      <div>
        <Label htmlFor="description">Décrivez votre projet (optionnel)</Label>
        <Textarea
          id="description"
          maxLength={4000}
          placeholder="Que vendez-vous, à qui, et quel problème résolvez-vous ? L'assistant IA s'en servira pour générer votre positionnement."
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
      </div>

      {error && <p className="text-sm text-red-600">{error}</p>}

      <Button type="submit" loading={loading} className="w-full" size="lg">
        Créer le projet
      </Button>
    </form>
  );
}
