"use client";

import { useState } from "react";
import { Sparkles, Copy, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label, Textarea } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import type { Positioning } from "@/types/database";

export function AssistantClient({
  projectId,
  initialDescription,
  initialPositioning,
}: {
  projectId: string;
  initialDescription: string;
  initialPositioning: Positioning | null;
}) {
  const [description, setDescription] = useState(initialDescription);
  const [positioning, setPositioning] = useState(initialPositioning);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleGenerate() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/ai/positioning", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectId, description }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Erreur de génération");
      setPositioning(data.positioning);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Erreur inattendue");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-navy-600" />
            Décrivez votre projet
          </CardTitle>
          <CardDescription>
            Que vendez-vous, à qui, quel problème résolvez-vous, qu'est-ce qui
            vous différencie ? Plus c'est précis, meilleur sera le résultat.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Label htmlFor="description" className="sr-only">
            Description du projet
          </Label>
          <Textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            minLength={20}
            maxLength={4000}
            placeholder="Ex. : Je lance un outil qui aide les freelances à créer leurs factures en 30 secondes depuis Notion. Cible : freelances tech francophones. Alternative actuelle : Excel ou des outils complexes et chers…"
          />
          {error && <p className="mt-3 text-sm text-red-600">{error}</p>}
          <Button
            onClick={handleGenerate}
            loading={loading}
            disabled={description.trim().length < 20}
            className="mt-4"
          >
            <Sparkles className="h-4 w-4" />
            {positioning ? "Régénérer" : "Générer mon positionnement"}
          </Button>
        </CardContent>
      </Card>

      {positioning && (
        <div className="grid gap-6 animate-fade-up">
          <ResultBlock title="Positionnement" content={positioning.positioning} />
          <ResultBlock
            title="Proposition de valeur"
            content={positioning.value_proposition}
          />
          <ResultBlock title="Pitch court" content={positioning.short_pitch} />
          <ResultBlock
            title="Description longue"
            content={positioning.long_description}
          />

          <Card>
            <CardHeader>
              <CardTitle>FAQ</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {positioning.faq.map((item, i) => (
                <div key={i}>
                  <p className="text-sm font-medium text-navy-950">
                    {item.question}
                  </p>
                  <p className="mt-1 text-sm leading-relaxed text-navy-600">
                    {item.answer}
                  </p>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Appels à l'action</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-wrap gap-2">
              {positioning.ctas.map((cta, i) => (
                <span
                  key={i}
                  className="rounded-full border border-navy-200 bg-navy-50 px-4 py-1.5 text-sm font-medium text-navy-800"
                >
                  {cta}
                </span>
              ))}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}

function ResultBlock({ title, content }: { title: string; content: string }) {
  const [copied, setCopied] = useState(false);

  async function handleCopy() {
    await navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>{title}</CardTitle>
        <Button variant="ghost" size="sm" onClick={handleCopy}>
          {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
          {copied ? "Copié" : "Copier"}
        </Button>
      </CardHeader>
      <CardContent>
        <p className="whitespace-pre-wrap text-sm leading-relaxed text-navy-700">
          {content}
        </p>
      </CardContent>
    </Card>
  );
}
