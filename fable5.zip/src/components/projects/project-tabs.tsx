"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

const TABS = [
  { suffix: "", label: "Vue d'ensemble" },
  { suffix: "/assistant", label: "Assistant IA" },
  { suffix: "/content", label: "Contenus" },
  { suffix: "/checklist", label: "Checklist" },
  { suffix: "/calendar", label: "Calendrier" },
];

export function ProjectTabs({ projectId }: { projectId: string }) {
  const pathname = usePathname();
  const base = `/projects/${projectId}`;

  return (
    <nav className="mb-8 flex gap-1 overflow-x-auto border-b border-navy-100">
      {TABS.map((tab) => {
        const href = base + tab.suffix;
        const active = pathname === href;
        return (
          <Link
            key={tab.suffix}
            href={href}
            className={cn(
              "whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-medium transition-colors",
              active
                ? "border-navy-900 text-navy-950"
                : "border-transparent text-navy-500 hover:text-navy-900"
            )}
          >
            {tab.label}
          </Link>
        );
      })}
    </nav>
  );
}
