"use client";

import { useState } from "react";
import Link from "next/link";
import { Sparkles, Copy, Check } from "lucide-react";
import { CONTENT_TYPES, contentTypeMeta } from "@/lib/content-types";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn, formatDate } from "@/lib/utils";
import type { ContentType, GeneratedContent } from "@/types/database";

export function ContentGeneratorClient({
  projectId,
  hasPositioning,
  initialHistory,
}: {
  projectId: string;
  hasPositioning: boolean;
  initialHistory: GeneratedContent[];
}) {
  const [selected, setSelected] = useState<ContentType>("linkedin_post");
  const [instructions, setInstructions] = useState("");
  const [history, setHistory] = useState(initialHistory);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleGenerate() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/ai/content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          projectId,
          type: selected,
          instructions: instructions || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Erreur de génération");
      setHistory((prev) => [data.content, ...prev]);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Erreur inattendue");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      {!hasPositioning && (
        <div className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
          💡 Générez d'abord votre{" "}
          <Link
            href={`/projects/${projectId}/assistant`}
            className="font-medium underline"
          >
            positionnement avec l'assistant IA
          </Link>{" "}
          : vos contenus seront beaucoup plus pertinents.
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Que voulez-vous créer ?</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {CONTENT_TYPES.map((type) => (
              <button
                key={type.id}
                type="button"
                onClick={() => setSelected(type.id)}
                className={cn(
                  "rounded-lg border p-4 text-left transition-colors",
                  selected === type.id
                    ? "border-navy-700 bg-navy-50 ring-1 ring-navy-700"
                    : "border-navy-100 hover:border-navy-300"
                )}
              >
                <div className="text-xl">{type.emoji}</div>
                <div className="mt-1 text-sm font-medium text-navy-950">
                  {type.label}
                </div>
                <div className="mt-0.5 text-xs text-navy-500">
                  {type.description}
                </div>
              </button>
            ))}
          </div>

          <div className="mt-4">
            <Label htmlFor="instructions">
              Instructions supplémentaires (optionnel)
            </Label>
            <Input
              id="instructions"
              maxLength={1000}
              placeholder="Ex. : insister sur l'offre de lancement -30%, ton humoristique…"
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
            />
          </div>

          {error && <p className="mt-3 text-sm text-red-600">{error}</p>}

          <Button onClick={handleGenerate} loading={loading} className="mt-4">
            <Sparkles className="h-4 w-4" />
            Générer
          </Button>
        </CardContent>
      </Card>

      {history.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-navy-400">
            Contenus générés
          </h2>
          {history.map((item) => (
            <HistoryCard key={item.id} item={item} />
          ))}
        </div>
      )}
    </div>
  );
}

function HistoryCard({ item }: { item: GeneratedContent }) {
  const [copied, setCopied] = useState(false);
  const meta = contentTypeMeta(item.type);

  async function handleCopy() {
    await navigator.clipboard.writeText(item.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <Card className="animate-fade-up">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-sm">
            {meta.emoji} {meta.label}
          </CardTitle>
          <p className="mt-0.5 text-xs text-navy-400">
            {formatDate(item.created_at)}
          </p>
        </div>
        <Button variant="ghost" size="sm" onClick={handleCopy}>
          {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
          {copied ? "Copié" : "Copier"}
        </Button>
      </CardHeader>
      <CardContent>
        <p className="whitespace-pre-wrap text-sm leading-relaxed text-navy-700">
          {item.content}
        </p>
      </CardContent>
    </Card>
  );
}
