"use client";

import { useState } from "react";
import { Check } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn, formatDate } from "@/lib/utils";
import type { Milestone } from "@/types/database";

function milestoneDate(launchDate: string, offsetDays: number): string {
  const d = new Date(launchDate);
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString();
}

export function CalendarClient({
  initialMilestones,
  launchDate,
}: {
  initialMilestones: Milestone[];
  launchDate: string | null;
}) {
  const [milestones, setMilestones] = useState(initialMilestones);
  const supabase = createClient();

  async function toggleAction(milestone: Milestone, index: number) {
    const nextActions = milestone.actions.map((a, i) =>
      i === index ? { ...a, done: !a.done } : a
    );
    // Mise à jour optimiste, rollback si la requête échoue.
    setMilestones((prev) =>
      prev.map((m) =>
        m.id === milestone.id ? { ...m, actions: nextActions } : m
      )
    );
    const { error } = await supabase
      .from("milestones")
      .update({ actions: nextActions })
      .eq("id", milestone.id);
    if (error) {
      setMilestones((prev) =>
        prev.map((m) =>
          m.id === milestone.id ? { ...m, actions: milestone.actions } : m
        )
      );
    }
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  return (
    <div>
      {!launchDate && (
        <div className="mb-6 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
          📅 Définissez une date de lancement pour voir les dates réelles de
          chaque étape.
        </div>
      )}

      <ol className="relative space-y-6 border-l-2 border-navy-100 pl-8">
        {milestones.map((milestone) => {
          const date = launchDate
            ? milestoneDate(launchDate, milestone.offset_days)
            : null;
          const isPast = date ? new Date(date) < today : false;
          const isLaunchDay = milestone.offset_days === 0;
          const allDone =
            milestone.actions.length > 0 &&
            milestone.actions.every((a) => a.done);

          return (
            <li key={milestone.id} className="relative">
              <span
                className={cn(
                  "absolute -left-[2.45rem] flex h-5 w-5 items-center justify-center rounded-full border-2",
                  allDone
                    ? "border-emerald-500 bg-emerald-500 text-white"
                    : isLaunchDay
                      ? "border-navy-900 bg-navy-900"
                      : "border-navy-200 bg-white"
                )}
              >
                {allDone && <Check className="h-3 w-3" />}
              </span>

              <Card className={cn(isLaunchDay && "border-navy-700 ring-1 ring-navy-700")}>
                <CardContent className="pt-5">
                  <div className="mb-3 flex items-center justify-between">
                    <h3 className="font-semibold text-navy-950">
                      {milestone.title}
                    </h3>
                    <div className="flex items-center gap-2">
                      {date && (
                        <span className="text-xs text-navy-400">
                          {formatDate(date)}
                        </span>
                      )}
                      {isPast && !allDone && (
                        <Badge variant="warning">En retard</Badge>
                      )}
                      {allDone && <Badge variant="success">Terminé</Badge>}
                    </div>
                  </div>

                  <ul className="space-y-1">
                    {milestone.actions.map((action, i) => (
                      <li key={i}>
                        <button
                          type="button"
                          onClick={() => toggleAction(milestone, i)}
                          className="flex w-full items-start gap-3 rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-navy-50"
                        >
                          <span
                            className={cn(
                              "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors",
                              action.done
                                ? "border-navy-900 bg-navy-900 text-white"
                                : "border-navy-300 bg-white"
                            )}
                          >
                            {action.done && <Check className="h-3 w-3" />}
                          </span>
                          <span
                            className={cn(
                              "text-sm",
                              action.done
                                ? "text-navy-400 line-through"
                                : "text-navy-800"
                            )}
                          >
                            {action.label}
                          </span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
