"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Check } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { CATEGORY_LABELS, CATEGORY_ORDER, computeReadiness } from "@/lib/scoring";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import type { ChecklistItem } from "@/types/database";

export function ChecklistClient({
  initialItems,
}: {
  initialItems: ChecklistItem[];
}) {
  const router = useRouter();
  const [items, setItems] = useState(initialItems);
  const supabase = createClient();

  const readiness = useMemo(() => computeReadiness(items), [items]);

  async function toggle(item: ChecklistItem) {
    const next = !item.is_done;
    // Mise à jour optimiste, rollback si la requête échoue.
    setItems((prev) =>
      prev.map((i) => (i.id === item.id ? { ...i, is_done: next } : i))
    );
    const { error } = await supabase
      .from("checklist_items")
      .update({ is_done: next })
      .eq("id", item.id);
    if (error) {
      setItems((prev) =>
        prev.map((i) => (i.id === item.id ? { ...i, is_done: !next } : i))
      );
    } else {
      router.refresh();
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="flex items-center gap-6 pt-5">
          <div className="text-3xl font-bold text-navy-950">
            {readiness.global}
            <span className="text-base font-normal text-navy-400">/100</span>
          </div>
          <div className="flex-1">
            <Progress value={readiness.global} />
            <p className="mt-2 text-xs text-navy-500">
              {readiness.doneCount}/{readiness.totalCount} tâches terminées —
              chaque catégorie compte pour 20 points.
            </p>
          </div>
        </CardContent>
      </Card>

      {CATEGORY_ORDER.map((category) => {
        const catItems = items.filter((i) => i.category === category);
        if (catItems.length === 0) return null;
        const score = readiness.categories.find(
          (c) => c.category === category
        );

        return (
          <Card key={category}>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>{CATEGORY_LABELS[category]}</CardTitle>
              <span
                className={cn(
                  "text-sm font-semibold",
                  score && score.score >= 20 ? "text-emerald-600" : "text-navy-500"
                )}
              >
                {score?.score ?? 0}/20
              </span>
            </CardHeader>
            <CardContent className="space-y-1">
              {catItems.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => toggle(item)}
                  className="flex w-full items-start gap-3 rounded-lg px-3 py-2.5 text-left transition-colors hover:bg-navy-50"
                >
                  <span
                    className={cn(
                      "mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition-colors",
                      item.is_done
                        ? "border-navy-900 bg-navy-900 text-white"
                        : "border-navy-300 bg-white"
                    )}
                  >
                    {item.is_done && <Check className="h-3.5 w-3.5" />}
                  </span>
                  <span className="flex-1">
                    <span
                      className={cn(
                        "block text-sm",
                        item.is_done
                          ? "text-navy-400 line-through"
                          : "text-navy-900"
                      )}
                    >
                      {item.title}
                    </span>
                    {item.description && (
                      <span className="mt-0.5 block text-xs text-navy-500">
                        {item.description}
                      </span>
                    )}
                  </span>
                  {item.weight >= 4 && !item.is_done && (
                    <span className="mt-0.5 shrink-0 rounded-full bg-amber-50 px-2 py-0.5 text-xs font-medium text-amber-700">
                      Priorité
                    </span>
                  )}
                </button>
              ))}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
