export type ProjectType =
  | "saas"
  | "ebook"
  | "formation"
  | "newsletter"
  | "template"
  | "application"
  | "agence"
  | "coaching";

export type PlanType = "free" | "pro" | "unlimited";

export type ChecklistCategory =
  | "branding"
  | "landing_page"
  | "seo"
  | "social"
  | "email"
  | "acquisition"
  | "launch"
  | "post_launch";

export type ContentType =
  | "linkedin_post"
  | "twitter_post"
  | "launch_email"
  | "community_message"
  | "product_announcement"
  | "product_hunt";

export interface Positioning {
  positioning: string;
  value_proposition: string;
  short_pitch: string;
  long_description: string;
  faq: { question: string; answer: string }[];
  ctas: string[];
}

export interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  plan: PlanType;
  stripe_customer_id: string | null;
  stripe_subscription_id: string | null;
  plan_renews_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Project {
  id: string;
  user_id: string;
  name: string;
  type: ProjectType;
  description: string | null;
  launch_date: string | null;
  positioning: Positioning | null;
  created_at: string;
  updated_at: string;
}

export interface ChecklistItem {
  id: string;
  project_id: string;
  category: ChecklistCategory;
  title: string;
  description: string | null;
  weight: number;
  is_done: boolean;
  sort_order: number;
  created_at: string;
}

export interface MilestoneAction {
  label: string;
  done: boolean;
}

export interface Milestone {
  id: string;
  project_id: string;
  offset_days: number;
  title: string;
  actions: MilestoneAction[];
  created_at: string;
}

export interface GeneratedContent {
  id: string;
  project_id: string;
  type: ContentType;
  content: string;
  created_at: string;
}
