import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });

export const metadata: Metadata = {
  title: {
    default: "LaunchPilot — votre copilote de lancement",
    template: "%s · LaunchPilot",
  },
  description:
    "LaunchPilot transforme un lancement de produit digital complexe en un processus guidé étape par étape : positionnement IA, contenus, checklist et calendrier de lancement.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fr">
      <body className={`${inter.variable} font-sans bg-white text-navy-950`}>
        {children}
      </body>
    </html>
  );
}
