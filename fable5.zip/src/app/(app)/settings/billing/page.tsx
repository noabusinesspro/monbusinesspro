import Link from "next/link";
import { redirect } from "next/navigation";
import { Check } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { getPlan } from "@/lib/plans";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ManageSubscriptionButton } from "@/components/billing/manage-subscription-button";
import { formatDate } from "@/lib/utils";
import type { Profile } from "@/types/database";

export const metadata = { title: "Abonnement" };

export default async function BillingPage({
  searchParams,
}: {
  searchParams: Promise<{ success?: string }>;
}) {
  const { success } = await searchParams;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single<Profile>();

  const plan = getPlan(profile?.plan ?? "free");

  return (
    <div className="mx-auto max-w-2xl animate-fade-up">
      <h1 className="text-2xl font-bold text-navy-950">Abonnement</h1>
      <p className="mt-1 text-sm text-navy-500">
        Gérez votre plan et votre facturation.
      </p>

      {success && (
        <div className="mt-6 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
          🎉 Abonnement activé ! Votre plan sera mis à jour dans quelques
          secondes.
        </div>
      )}

      <Card className="mt-6">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Plan actuel</CardTitle>
            <Badge variant={plan.id === "free" ? "default" : "navy"}>
              {plan.name}
            </Badge>
          </div>
          <CardDescription>
            {plan.price > 0
              ? `${plan.price}€/mois${
                  profile?.plan_renews_at
                    ? ` · Renouvellement le ${formatDate(profile.plan_renews_at)}`
                    : ""
                }`
              : "Plan gratuit — sans engagement"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {plan.features.map((feature) => (
              <li
                key={feature}
                className="flex items-start gap-2 text-sm text-navy-700"
              >
                <Check className="mt-0.5 h-4 w-4 shrink-0 text-navy-600" />
                {feature}
              </li>
            ))}
          </ul>

          <div className="mt-6 flex gap-3">
            {plan.id === "free" ? (
              <Link href="/pricing">
                <Button>Passer au plan supérieur</Button>
              </Link>
            ) : (
              <>
                <ManageSubscriptionButton />
                {plan.id === "pro" && (
                  <Link href="/pricing">
                    <Button variant="secondary">Voir Unlimited</Button>
                  </Link>
                )}
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
