import Link from "next/link";
import { Plus, CalendarDays, ArrowRight } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { computeReadiness } from "@/lib/scoring";
import { projectTypeMeta } from "@/lib/project-types";
import { formatDate, daysUntil } from "@/lib/utils";
import type { ChecklistItem, Project } from "@/types/database";

export const metadata = { title: "Dashboard" };

export default async function DashboardPage() {
  const supabase = await createClient();

  const { data: projects } = await supabase
    .from("projects")
    .select("*")
    .order("created_at", { ascending: false })
    .returns<Project[]>();

  const { data: allItems } = await supabase
    .from("checklist_items")
    .select("*")
    .returns<ChecklistItem[]>();

  const itemsByProject = new Map<string, ChecklistItem[]>();
  for (const item of allItems ?? []) {
    const list = itemsByProject.get(item.project_id) ?? [];
    list.push(item);
    itemsByProject.set(item.project_id, list);
  }

  return (
    <div className="animate-fade-up">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-navy-950">Vos lancements</h1>
          <p className="mt-1 text-sm text-navy-500">
            Suivez la préparation de chacun de vos projets.
          </p>
        </div>
        <Link href="/projects/new">
          <Button>
            <Plus className="h-4 w-4" />
            Nouveau projet
          </Button>
        </Link>
      </div>

      {!projects?.length ? (
        <Card>
          <CardContent className="flex flex-col items-center py-16 text-center">
            <div className="mb-4 text-5xl">🚀</div>
            <h2 className="text-lg font-semibold text-navy-950">
              Aucun projet pour le moment
            </h2>
            <p className="mt-2 max-w-sm text-sm text-navy-500">
              Créez votre premier projet : LaunchPilot génère automatiquement
              votre checklist et votre calendrier de lancement.
            </p>
            <Link href="/projects/new" className="mt-6">
              <Button>
                <Plus className="h-4 w-4" />
                Créer mon premier projet
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {projects.map((project) => {
            const readiness = computeReadiness(
              itemsByProject.get(project.id) ?? []
            );
            const meta = projectTypeMeta(project.type);
            const remaining = readiness.totalCount - readiness.doneCount;
            const days = project.launch_date
              ? daysUntil(project.launch_date)
              : null;

            return (
              <Link key={project.id} href={`/projects/${project.id}`}>
                <Card className="h-full transition-shadow hover:shadow-card-hover">
                  <CardContent className="pt-5">
                    <div className="mb-3 flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{meta.emoji}</span>
                        <div>
                          <h3 className="font-semibold text-navy-950">
                            {project.name}
                          </h3>
                          <span className="text-xs text-navy-400">
                            {meta.label}
                          </span>
                        </div>
                      </div>
                      <ArrowRight className="h-4 w-4 text-navy-300" />
                    </div>

                    <div className="mb-2 flex items-center justify-between text-sm">
                      <span className="text-navy-500">Progression</span>
                      <span className="font-semibold text-navy-900">
                        {readiness.global}%
                      </span>
                    </div>
                    <Progress value={readiness.global} />

                    <div className="mt-4 flex items-center justify-between text-sm">
                      <span className="flex items-center gap-1.5 text-navy-500">
                        <CalendarDays className="h-4 w-4" />
                        {project.launch_date
                          ? formatDate(project.launch_date)
                          : "Date à définir"}
                      </span>
                      {days !== null && days >= 0 && (
                        <Badge variant={days <= 7 ? "warning" : "default"}>
                          J-{days}
                        </Badge>
                      )}
                      {days !== null && days < 0 && (
                        <Badge variant="success">Lancé 🎉</Badge>
                      )}
                    </div>

                    <p className="mt-3 text-xs text-navy-400">
                      {remaining > 0
                        ? `${remaining} tâche${remaining > 1 ? "s" : ""} restante${remaining > 1 ? "s" : ""}`
                        : "Toutes les tâches sont terminées ✓"}
                    </p>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
