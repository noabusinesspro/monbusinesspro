import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { checklistForType } from "@/lib/checklist-templates";
import type { ProjectType } from "@/types/database";

export const metadata = { title: "Templates" };

interface LaunchTemplate {
  type: ProjectType;
  emoji: string;
  title: string;
  description: string;
  highlights: string[];
}

const TEMPLATES: LaunchTemplate[] = [
  {
    type: "saas",
    emoji: "⚡",
    title: "Lancement SaaS",
    description:
      "De la liste d'attente au Product Hunt : le plan complet pour lancer un logiciel en ligne.",
    highlights: ["Page Product Hunt", "Build in public", "Tunnel de paiement"],
  },
  {
    type: "newsletter",
    emoji: "✉️",
    title: "Lancement Newsletter",
    description:
      "Construire une audience avant le premier numéro et convertir les premiers abonnés.",
    highlights: ["Croissance de liste", "Cross-promotions", "Premier numéro"],
  },
  {
    type: "ebook",
    emoji: "📘",
    title: "Lancement Ebook",
    description:
      "Vendre un livre numérique : extrait gratuit, preuve sociale et séquence email de vente.",
    highlights: ["Chapitre gratuit", "Séquence de vente", "Mentions presse"],
  },
  {
    type: "formation",
    emoji: "🎓",
    title: "Lancement Formation",
    description:
      "Remplir une cohorte ou vendre un cours en ligne avec une offre de lancement irrésistible.",
    highlights: ["Leçon découverte", "Webinaire de vente", "Offre early bird"],
  },
  {
    type: "agence",
    emoji: "🏢",
    title: "Lancement Agence",
    description:
      "Productiser une offre de services et générer les premiers leads qualifiés.",
    highlights: ["Offre productisée", "Études de cas", "Prospection ciblée"],
  },
  {
    type: "coaching",
    emoji: "🎯",
    title: "Lancement Coaching",
    description:
      "Lancer une offre d'accompagnement avec une approche fondée sur la confiance.",
    highlights: ["Appels découverte", "Témoignages", "Contenu d'autorité"],
  },
];

export default function TemplatesPage() {
  return (
    <div className="animate-fade-up">
      <h1 className="text-2xl font-bold text-navy-950">
        Bibliothèque de templates
      </h1>
      <p className="mt-1 text-sm text-navy-500">
        Des plans de lancement éprouvés, adaptés à chaque type de projet. La
        checklist et le calendrier sont générés automatiquement.
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {TEMPLATES.map((template) => {
          const taskCount = checklistForType(template.type).length;
          return (
            <Link
              key={template.type}
              href={`/projects/new?type=${template.type}`}
            >
              <Card className="h-full transition-shadow hover:shadow-card-hover">
                <CardContent className="pt-5">
                  <div className="flex items-start justify-between">
                    <span className="text-3xl">{template.emoji}</span>
                    <ArrowRight className="h-4 w-4 text-navy-300" />
                  </div>
                  <h2 className="mt-3 font-semibold text-navy-950">
                    {template.title}
                  </h2>
                  <p className="mt-1 text-sm leading-relaxed text-navy-600">
                    {template.description}
                  </p>
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {template.highlights.map((h) => (
                      <Badge key={h}>{h}</Badge>
                    ))}
                  </div>
                  <p className="mt-3 text-xs text-navy-400">
                    {taskCount} tâches · Calendrier J-30 → J+7
                  </p>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
