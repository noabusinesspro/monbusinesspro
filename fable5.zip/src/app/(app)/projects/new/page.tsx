import { NewProjectForm } from "@/components/projects/new-project-form";
import { PROJECT_TYPES } from "@/lib/project-types";
import type { ProjectType } from "@/types/database";

export const metadata = { title: "Nouveau projet" };

export default async function NewProjectPage({
  searchParams,
}: {
  searchParams: Promise<{ type?: string }>;
}) {
  const { type } = await searchParams;
  const initialType = PROJECT_TYPES.some((t) => t.id === type)
    ? (type as ProjectType)
    : "saas";
  return (
    <div className="mx-auto max-w-2xl animate-fade-up">
      <h1 className="text-2xl font-bold text-navy-950">Nouveau lancement</h1>
      <p className="mt-1 text-sm text-navy-500">
        LaunchPilot va générer une checklist et un calendrier adaptés à votre
        type de projet.
      </p>
      <div className="mt-8">
        <NewProjectForm initialType={initialType} />
      </div>
    </div>
  );
}
