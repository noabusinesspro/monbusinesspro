import { getProjectOr404 } from "@/lib/get-project";
import { AssistantClient } from "@/components/projects/assistant-client";

export const metadata = { title: "Assistant IA" };

export default async function AssistantPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const project = await getProjectOr404(id);

  return (
    <AssistantClient
      projectId={project.id}
      initialDescription={project.description ?? ""}
      initialPositioning={project.positioning}
    />
  );
}
