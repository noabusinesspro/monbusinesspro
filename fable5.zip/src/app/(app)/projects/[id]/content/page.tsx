import { createClient } from "@/lib/supabase/server";
import { getProjectOr404 } from "@/lib/get-project";
import { ContentGeneratorClient } from "@/components/projects/content-generator-client";
import type { GeneratedContent } from "@/types/database";

export const metadata = { title: "Générateur de contenu" };

export default async function ContentPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const project = await getProjectOr404(id);

  const supabase = await createClient();
  const { data: history } = await supabase
    .from("generated_content")
    .select("*")
    .eq("project_id", id)
    .order("created_at", { ascending: false })
    .limit(20)
    .returns<GeneratedContent[]>();

  return (
    <ContentGeneratorClient
      projectId={project.id}
      hasPositioning={!!project.positioning}
      initialHistory={history ?? []}
    />
  );
}
