import { createClient } from "@/lib/supabase/server";
import { getProjectOr404 } from "@/lib/get-project";
import { CalendarClient } from "@/components/projects/calendar-client";
import type { Milestone } from "@/types/database";

export const metadata = { title: "Calendrier de lancement" };

export default async function CalendarPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const project = await getProjectOr404(id);

  const supabase = await createClient();
  const { data: milestones } = await supabase
    .from("milestones")
    .select("*")
    .eq("project_id", id)
    .order("offset_days")
    .returns<Milestone[]>();

  return (
    <CalendarClient
      initialMilestones={milestones ?? []}
      launchDate={project.launch_date}
    />
  );
}
