import { Badge } from "@/components/ui/badge";
import { ProjectTabs } from "@/components/projects/project-tabs";
import { getProjectOr404 } from "@/lib/get-project";
import { projectTypeMeta } from "@/lib/project-types";
import { formatDate, daysUntil } from "@/lib/utils";

export default async function ProjectLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const project = await getProjectOr404(id);
  const meta = projectTypeMeta(project.type);
  const days = project.launch_date ? daysUntil(project.launch_date) : null;

  return (
    <div className="animate-fade-up">
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-3xl">{meta.emoji}</span>
          <div>
            <h1 className="text-2xl font-bold text-navy-950">{project.name}</h1>
            <p className="text-sm text-navy-500">
              {meta.label}
              {project.launch_date &&
                ` · Lancement le ${formatDate(project.launch_date)}`}
            </p>
          </div>
        </div>
        {days !== null && days >= 0 && (
          <Badge variant={days <= 7 ? "warning" : "default"} className="text-sm">
            J-{days}
          </Badge>
        )}
        {days !== null && days < 0 && <Badge variant="success">Lancé 🎉</Badge>}
      </div>

      <ProjectTabs projectId={project.id} />
      {children}
    </div>
  );
}
