import { createClient } from "@/lib/supabase/server";
import { getProjectOr404 } from "@/lib/get-project";
import { ChecklistClient } from "@/components/projects/checklist-client";
import type { ChecklistItem } from "@/types/database";

export const metadata = { title: "Checklist" };

export default async function ChecklistPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  await getProjectOr404(id);

  const supabase = await createClient();
  const { data: items } = await supabase
    .from("checklist_items")
    .select("*")
    .eq("project_id", id)
    .order("sort_order")
    .returns<ChecklistItem[]>();

  return <ChecklistClient initialItems={items ?? []} />;
}
