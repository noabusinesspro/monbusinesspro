import Link from "next/link";
import { Sparkles, ListChecks, ArrowRight } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { getProjectOr404 } from "@/lib/get-project";
import { computeReadiness } from "@/lib/scoring";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress, ScoreRing } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import type { ChecklistItem } from "@/types/database";

export const metadata = { title: "Vue d'ensemble" };

export default async function ProjectOverviewPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const project = await getProjectOr404(id);

  const supabase = await createClient();
  const { data: items } = await supabase
    .from("checklist_items")
    .select("*")
    .eq("project_id", id)
    .returns<ChecklistItem[]>();

  const readiness = computeReadiness(items ?? []);
  const remaining = readiness.totalCount - readiness.doneCount;
  const weakest = [...readiness.categories].sort((a, b) => a.score - b.score)[0];

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      {/* Score de préparation */}
      <Card className="lg:col-span-1">
        <CardHeader>
          <CardTitle>Score de préparation</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col items-center">
          <ScoreRing value={readiness.global} label="/ 100" size={140} />
          <p className="mt-4 text-center text-sm text-navy-500">
            {remaining > 0
              ? `${remaining} tâche${remaining > 1 ? "s" : ""} restante${remaining > 1 ? "s" : ""} sur ${readiness.totalCount}`
              : "Vous êtes prêt à lancer 🎉"}
          </p>
          {weakest && weakest.score < 20 && (
            <p className="mt-2 text-center text-xs text-navy-400">
              Point faible : {weakest.label} ({weakest.score}/20)
            </p>
          )}
        </CardContent>
      </Card>

      {/* Détail par catégorie */}
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle>Détail par catégorie</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {readiness.categories.map((cat) => (
            <div key={cat.category}>
              <div className="mb-1 flex items-center justify-between text-sm">
                <span className="text-navy-700">{cat.label}</span>
                <span className="font-medium text-navy-900">
                  {cat.score}/20
                </span>
              </div>
              <Progress value={(cat.score / 20) * 100} />
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Prochaines actions */}
      <Card className="lg:col-span-3">
        <CardHeader>
          <CardTitle>Par où continuer</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          {!project.positioning && (
            <Link href={`/projects/${id}/assistant`}>
              <div className="flex items-center justify-between rounded-lg border border-navy-100 p-4 transition-colors hover:bg-navy-50">
                <div className="flex items-center gap-3">
                  <Sparkles className="h-5 w-5 text-navy-600" />
                  <div>
                    <div className="text-sm font-medium text-navy-950">
                      Générer votre positionnement
                    </div>
                    <div className="text-xs text-navy-500">
                      Pitch, proposition de valeur, FAQ et CTA en 30 secondes
                    </div>
                  </div>
                </div>
                <ArrowRight className="h-4 w-4 text-navy-300" />
              </div>
            </Link>
          )}
          <Link href={`/projects/${id}/checklist`}>
            <div className="flex items-center justify-between rounded-lg border border-navy-100 p-4 transition-colors hover:bg-navy-50">
              <div className="flex items-center gap-3">
                <ListChecks className="h-5 w-5 text-navy-600" />
                <div>
                  <div className="text-sm font-medium text-navy-950">
                    Avancer sur la checklist
                  </div>
                  <div className="text-xs text-navy-500">
                    {remaining} tâche{remaining > 1 ? "s" : ""} à cocher
                  </div>
                </div>
              </div>
              <ArrowRight className="h-4 w-4 text-navy-300" />
            </div>
          </Link>
          {project.positioning && (
            <Link href={`/projects/${id}/content`}>
              <div className="flex items-center justify-between rounded-lg border border-navy-100 p-4 transition-colors hover:bg-navy-50">
                <div className="flex items-center gap-3">
                  <Sparkles className="h-5 w-5 text-navy-600" />
                  <div>
                    <div className="text-sm font-medium text-navy-950">
                      Générer vos contenus de lancement
                    </div>
                    <div className="text-xs text-navy-500">
                      Posts, emails, Product Hunt…
                    </div>
                  </div>
                </div>
                <ArrowRight className="h-4 w-4 text-navy-300" />
              </div>
            </Link>
          )}
        </CardContent>
      </Card>

      {!project.positioning && (
        <Card className="border-dashed lg:col-span-3">
          <CardContent className="flex flex-col items-center py-8 text-center">
            <p className="text-sm text-navy-500">
              💡 Commencez par l'assistant IA : il génère le positionnement qui
              alimentera ensuite tous vos contenus de lancement.
            </p>
            <Link href={`/projects/${id}/assistant`} className="mt-4">
              <Button size="sm">
                <Sparkles className="h-4 w-4" />
                Lancer l'assistant
              </Button>
            </Link>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
