import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { getOpenAI, OPENAI_MODEL } from "@/lib/openai";
import { checkAiQuota, recordAiUsage } from "@/lib/ai-quota";
import { projectTypeMeta } from "@/lib/project-types";
import type { Positioning, Profile, Project } from "@/types/database";

const bodySchema = z.object({
  projectId: z.string().uuid(),
  description: z.string().min(20).max(4000),
});

const SYSTEM_PROMPT = `Tu es un expert en positionnement produit et en copywriting pour des lancements de produits digitaux.
Tu réponds en français, dans un ton clair, direct et orienté bénéfices.
Tu réponds UNIQUEMENT avec un objet JSON valide, sans markdown, avec exactement ces clés :
{
  "positioning": "le positionnement en 1-2 phrases (pour qui, contre quelle alternative, différenciation)",
  "value_proposition": "la proposition de valeur en 1 phrase percutante",
  "short_pitch": "un pitch de 2-3 phrases utilisable en bio ou en intro",
  "long_description": "une description longue de 150-250 mots pour une page de vente",
  "faq": [{ "question": "...", "answer": "..." }] (5 à 6 questions/réponses),
  "ctas": ["...", "..."] (4 à 5 appels à l'action courts et variés)
}`;

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  }

  const parsed = bodySchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Décrivez votre projet en au moins 20 caractères." },
      { status: 400 }
    );
  }
  const { projectId, description } = parsed.data;

  // RLS garantit que le projet appartient à l'utilisateur.
  const { data: project } = await supabase
    .from("projects")
    .select("*")
    .eq("id", projectId)
    .single<Project>();
  if (!project) {
    return NextResponse.json({ error: "Projet introuvable" }, { status: 404 });
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single<Profile>();

  const quotaError = await checkAiQuota(user.id, profile?.plan ?? "free");
  if (quotaError) {
    return NextResponse.json({ error: quotaError }, { status: 402 });
  }

  const typeMeta = projectTypeMeta(project.type);
  const completion = await getOpenAI().chat.completions.create({
    model: OPENAI_MODEL,
    response_format: { type: "json_object" },
    temperature: 0.7,
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      {
        role: "user",
        content: `Projet : "${project.name}" (type : ${typeMeta.label}).\nDescription du créateur :\n${description}`,
      },
    ],
  });

  let positioning: Positioning;
  try {
    positioning = JSON.parse(completion.choices[0].message.content ?? "");
  } catch {
    return NextResponse.json(
      { error: "Réponse IA invalide, réessayez." },
      { status: 502 }
    );
  }

  const { error: updateError } = await supabase
    .from("projects")
    .update({ positioning, description })
    .eq("id", projectId);
  if (updateError) {
    return NextResponse.json({ error: "Erreur d'enregistrement" }, { status: 500 });
  }

  await recordAiUsage(user.id, "positioning");

  return NextResponse.json({ positioning });
}
