import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { getOpenAI, OPENAI_MODEL } from "@/lib/openai";
import { checkAiQuota, recordAiUsage } from "@/lib/ai-quota";
import { contentTypeMeta } from "@/lib/content-types";
import { projectTypeMeta } from "@/lib/project-types";
import type { Profile, Project } from "@/types/database";

const bodySchema = z.object({
  projectId: z.string().uuid(),
  type: z.enum([
    "linkedin_post",
    "twitter_post",
    "launch_email",
    "community_message",
    "product_announcement",
    "product_hunt",
  ]),
  instructions: z.string().max(1000).optional(),
});

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  }

  const parsed = bodySchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: "Requête invalide" }, { status: 400 });
  }
  const { projectId, type, instructions } = parsed.data;

  const { data: project } = await supabase
    .from("projects")
    .select("*")
    .eq("id", projectId)
    .single<Project>();
  if (!project) {
    return NextResponse.json({ error: "Projet introuvable" }, { status: 404 });
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single<Profile>();

  const quotaError = await checkAiQuota(user.id, profile?.plan ?? "free");
  if (quotaError) {
    return NextResponse.json({ error: quotaError }, { status: 402 });
  }

  const meta = contentTypeMeta(type);
  const typeMeta = projectTypeMeta(project.type);
  const p = project.positioning;

  const context = [
    `Projet : ${project.name} (${typeMeta.label})`,
    project.description && `Description : ${project.description}`,
    p?.value_proposition && `Proposition de valeur : ${p.value_proposition}`,
    p?.positioning && `Positionnement : ${p.positioning}`,
    p?.short_pitch && `Pitch : ${p.short_pitch}`,
    instructions && `Instructions supplémentaires : ${instructions}`,
  ]
    .filter(Boolean)
    .join("\n");

  const completion = await getOpenAI().chat.completions.create({
    model: OPENAI_MODEL,
    temperature: 0.8,
    messages: [
      {
        role: "system",
        content: `Tu es un copywriter expert en lancements de produits digitaux. Tu écris en français, ton direct et authentique, sans jargon marketing creux. Format demandé : ${meta.format}\nRéponds uniquement avec le contenu, sans préambule ni commentaire.`,
      },
      { role: "user", content: context },
    ],
  });

  const content = completion.choices[0].message.content?.trim();
  if (!content) {
    return NextResponse.json({ error: "Génération vide, réessayez." }, { status: 502 });
  }

  const { data: saved, error: insertError } = await supabase
    .from("generated_content")
    .insert({ project_id: projectId, type, content })
    .select()
    .single();
  if (insertError) {
    return NextResponse.json({ error: "Erreur d'enregistrement" }, { status: 500 });
  }

  await recordAiUsage(user.id, "content");

  return NextResponse.json({ content: saved });
}
