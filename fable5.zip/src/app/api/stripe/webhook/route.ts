import { NextResponse } from "next/server";
import type Stripe from "stripe";
import { getStripe } from "@/lib/stripe";
import { createAdminClient } from "@/lib/supabase/server";
import { planFromPriceId } from "@/lib/plans";

/**
 * Webhook Stripe — source de vérité de l'état d'abonnement.
 * Événements gérés :
 *  - checkout.session.completed       → activation du plan
 *  - customer.subscription.updated    → changement de plan / renouvellement
 *  - customer.subscription.deleted    → retour au plan gratuit
 */
export async function POST(request: Request) {
  const stripe = getStripe();
  const signature = request.headers.get("stripe-signature");
  if (!signature) {
    return NextResponse.json({ error: "Signature manquante" }, { status: 400 });
  }

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(
      await request.text(),
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch {
    return NextResponse.json({ error: "Signature invalide" }, { status: 400 });
  }

  const admin = createAdminClient();

  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object;
      const userId = session.metadata?.supabase_user_id;
      if (!userId || !session.subscription) break;

      const subscription = await stripe.subscriptions.retrieve(
        session.subscription as string
      );
      await applySubscription(admin, userId, subscription);
      break;
    }

    case "customer.subscription.updated": {
      const subscription = event.data.object;
      const userId = subscription.metadata?.supabase_user_id;
      if (!userId) break;
      await applySubscription(admin, userId, subscription);
      break;
    }

    case "customer.subscription.deleted": {
      const subscription = event.data.object;
      const userId = subscription.metadata?.supabase_user_id;
      if (!userId) break;
      await admin
        .from("profiles")
        .update({
          plan: "free",
          stripe_subscription_id: null,
          plan_renews_at: null,
        })
        .eq("id", userId);
      break;
    }
  }

  return NextResponse.json({ received: true });
}

async function applySubscription(
  admin: ReturnType<typeof createAdminClient>,
  userId: string,
  subscription: Stripe.Subscription
) {
  const priceId = subscription.items.data[0]?.price.id;
  const plan = priceId ? planFromPriceId(priceId) : null;
  const active = ["active", "trialing"].includes(subscription.status);
  const periodEnd = subscription.current_period_end;

  await admin
    .from("profiles")
    .update({
      plan: active && plan ? plan : "free",
      stripe_subscription_id: subscription.id,
      plan_renews_at: periodEnd ? new Date(periodEnd * 1000).toISOString() : null,
    })
    .eq("id", userId);
}
