import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { checklistForType } from "@/lib/checklist-templates";
import { MILESTONE_TEMPLATES } from "@/lib/calendar-templates";
import { getPlan } from "@/lib/plans";
import type { Profile } from "@/types/database";

const bodySchema = z.object({
  name: z.string().min(1).max(120),
  type: z.enum([
    "saas", "ebook", "formation", "newsletter",
    "template", "application", "agence", "coaching",
  ]),
  description: z.string().max(4000).optional(),
  launch_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().optional(),
});

/**
 * Crée un projet et provisionne sa checklist (adaptée au type)
 * et son calendrier de lancement (J-30 → J+7).
 */
export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  }

  const parsed = bodySchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: "Données invalides" }, { status: 400 });
  }

  // Limite de projets selon le plan.
  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single<Profile>();
  const plan = getPlan(profile?.plan ?? "free");

  const { count } = await supabase
    .from("projects")
    .select("id", { count: "exact", head: true })
    .eq("user_id", user.id);

  if ((count ?? 0) >= plan.maxProjects) {
    return NextResponse.json(
      {
        error: `Votre plan ${plan.name} est limité à ${plan.maxProjects} projet(s). Passez au plan supérieur pour en créer davantage.`,
      },
      { status: 402 }
    );
  }

  const { name, type, description, launch_date } = parsed.data;

  const { data: project, error } = await supabase
    .from("projects")
    .insert({
      user_id: user.id,
      name,
      type,
      description: description ?? null,
      launch_date: launch_date ?? null,
    })
    .select()
    .single();

  if (error || !project) {
    return NextResponse.json({ error: "Erreur de création" }, { status: 500 });
  }

  const checklist = checklistForType(type).map((item, i) => ({
    project_id: project.id,
    category: item.category,
    title: item.title,
    description: item.description ?? null,
    weight: item.weight ?? 1,
    sort_order: i,
  }));

  const milestones = MILESTONE_TEMPLATES.map((m) => ({
    project_id: project.id,
    offset_days: m.offset_days,
    title: m.title,
    actions: m.actions.map((label) => ({ label, done: false })),
  }));

  const [checklistRes, milestonesRes] = await Promise.all([
    supabase.from("checklist_items").insert(checklist),
    supabase.from("milestones").insert(milestones),
  ]);

  if (checklistRes.error || milestonesRes.error) {
    // Le projet sans checklist/calendrier est inutilisable : rollback.
    await supabase.from("projects").delete().eq("id", project.id);
    return NextResponse.json({ error: "Erreur de création" }, { status: 500 });
  }

  return NextResponse.json({ project }, { status: 201 });
}
