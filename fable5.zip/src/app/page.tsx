import Link from "next/link";
import {
  Sparkles,
  ListChecks,
  CalendarDays,
  PenSquare,
  Gauge,
  LayoutTemplate,
  ArrowRight,
  Rocket,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { PLANS } from "@/lib/plans";

const FEATURES = [
  {
    icon: Sparkles,
    title: "Assistant IA",
    description:
      "Décrivez votre projet : l'IA génère positionnement, proposition de valeur, pitch, description longue, FAQ et appels à l'action.",
  },
  {
    icon: PenSquare,
    title: "Générateur de contenu",
    description:
      "Posts LinkedIn et X, emails de lancement, messages communautés, annonces produit et kit Product Hunt — en un clic.",
  },
  {
    icon: ListChecks,
    title: "Checklist intelligente",
    description:
      "Branding, landing page, SEO, emailing, acquisition… une checklist qui s'adapte à votre type de projet.",
  },
  {
    icon: CalendarDays,
    title: "Calendrier de lancement",
    description:
      "De J-30 au jour J et jusqu'à J+7 : les actions recommandées au bon moment, sans rien oublier.",
  },
  {
    icon: Gauge,
    title: "Score de préparation",
    description:
      "Un score sur 100, détaillé par catégorie, pour savoir exactement où concentrer vos efforts.",
  },
  {
    icon: LayoutTemplate,
    title: "Bibliothèque de templates",
    description:
      "SaaS, newsletter, ebook, formation, agence, coaching : démarrez avec un plan de lancement éprouvé.",
  },
];

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-navy-100 bg-white/80 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
          <Link href="/" className="flex items-center gap-2 font-semibold text-navy-950">
            <Rocket className="h-5 w-5 text-navy-700" />
            LaunchPilot
          </Link>
          <nav className="flex items-center gap-2">
            <Link
              href="/pricing"
              className="px-3 py-2 text-sm font-medium text-navy-600 hover:text-navy-950"
            >
              Tarifs
            </Link>
            <Link
              href="/login"
              className="px-3 py-2 text-sm font-medium text-navy-600 hover:text-navy-950"
            >
              Connexion
            </Link>
            <Link href="/signup">
              <Button size="sm">Commencer gratuitement</Button>
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="mx-auto max-w-6xl px-6 pb-20 pt-24 text-center">
        <span className="mb-6 inline-flex items-center gap-2 rounded-full border border-navy-200 bg-navy-50 px-4 py-1.5 text-sm font-medium text-navy-700">
          <Sparkles className="h-4 w-4" />
          Votre copilote de lancement
        </span>
        <h1 className="mx-auto max-w-3xl text-5xl font-bold tracking-tight text-navy-950 sm:text-6xl">
          Lancez votre produit digital{" "}
          <span className="text-navy-600">sans rien laisser au hasard</span>
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-navy-600">
          LaunchPilot transforme un lancement complexe en un processus guidé
          étape par étape : positionnement généré par IA, contenus prêts à
          publier, checklist adaptée et calendrier J-30 → J+7.
        </p>
        <div className="mt-10 flex items-center justify-center gap-4">
          <Link href="/signup">
            <Button size="lg">
              Préparer mon lancement
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
          <Link href="/pricing">
            <Button size="lg" variant="secondary">
              Voir les tarifs
            </Button>
          </Link>
        </div>
        <p className="mt-4 text-sm text-navy-400">
          Gratuit pour votre premier lancement · Sans carte bancaire
        </p>
      </section>

      {/* Features */}
      <section className="border-t border-navy-100 bg-surface-subtle py-20">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="text-center text-3xl font-bold text-navy-950">
            Tout ce qu'il faut pour un lancement réussi
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-center text-navy-600">
            Pensé pour les créateurs de SaaS, ebooks, formations, newsletters,
            templates et applications.
          </p>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <div
                key={f.title}
                className="rounded-xl border border-navy-100 bg-white p-6 shadow-card transition-shadow hover:shadow-card-hover"
              >
                <div className="mb-4 inline-flex h-10 w-10 items-center justify-center rounded-lg bg-navy-900 text-white">
                  <f.icon className="h-5 w-5" />
                </div>
                <h3 className="font-semibold text-navy-950">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-navy-600">
                  {f.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing teaser */}
      <section className="py-20">
        <div className="mx-auto max-w-6xl px-6 text-center">
          <h2 className="text-3xl font-bold text-navy-950">
            Un prix simple, qui grandit avec vous
          </h2>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-6">
            {Object.values(PLANS).map((plan) => (
              <div
                key={plan.id}
                className="rounded-xl border border-navy-100 bg-white px-8 py-6 shadow-card"
              >
                <div className="text-sm font-medium text-navy-500">{plan.name}</div>
                <div className="mt-1 text-3xl font-bold text-navy-950">
                  {plan.price}€
                  <span className="text-sm font-normal text-navy-400">/mois</span>
                </div>
              </div>
            ))}
          </div>
          <Link href="/pricing" className="mt-8 inline-block">
            <Button variant="secondary">Comparer les plans</Button>
          </Link>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-navy-100 bg-navy-950 py-20 text-center">
        <div className="mx-auto max-w-2xl px-6">
          <h2 className="text-3xl font-bold text-white">
            Votre prochain lancement commence ici
          </h2>
          <p className="mt-4 text-navy-200">
            Rejoignez les créateurs qui lancent avec méthode plutôt qu'au feeling.
          </p>
          <Link href="/signup" className="mt-8 inline-block">
            <Button size="lg" className="bg-white text-navy-950 hover:bg-navy-50">
              Créer mon compte gratuit
            </Button>
          </Link>
        </div>
      </section>

      <footer className="border-t border-navy-100 py-8 text-center text-sm text-navy-400">
        © {new Date().getFullYear()} LaunchPilot — Le copilote de lancement des créateurs.
      </footer>
    </div>
  );
}
