import Link from "next/link";
import { Rocket } from "lucide-react";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-surface-subtle px-6">
      <Link
        href="/"
        className="mb-8 flex items-center gap-2 text-xl font-semibold text-navy-950"
      >
        <Rocket className="h-6 w-6 text-navy-700" />
        LaunchPilot
      </Link>
      <div className="w-full max-w-md rounded-xl border border-navy-100 bg-white p-8 shadow-card">
        {children}
      </div>
    </div>
  );
}
