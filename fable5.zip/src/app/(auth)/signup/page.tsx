import { Suspense } from "react";
import { AuthForm } from "@/components/auth/auth-form";

export const metadata = { title: "Inscription" };

export default function SignupPage() {
  return (
    <div className="flex flex-col items-center">
      <h1 className="mb-1 text-xl font-semibold text-navy-950">
        Préparez votre lancement
      </h1>
      <p className="mb-6 text-sm text-navy-500">
        Gratuit pour votre premier projet, sans carte bancaire.
      </p>
      <Suspense>
        <AuthForm mode="signup" />
      </Suspense>
    </div>
  );
}
