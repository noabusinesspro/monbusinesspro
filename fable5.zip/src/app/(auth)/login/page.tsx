import { Suspense } from "react";
import { AuthForm } from "@/components/auth/auth-form";

export const metadata = { title: "Connexion" };

export default function LoginPage() {
  return (
    <div className="flex flex-col items-center">
      <h1 className="mb-6 text-xl font-semibold text-navy-950">
        Bon retour à bord 👋
      </h1>
      <Suspense>
        <AuthForm mode="login" />
      </Suspense>
    </div>
  );
}
