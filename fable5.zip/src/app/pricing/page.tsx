import Link from "next/link";
import { Check, Rocket } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PLANS } from "@/lib/plans";
import { createClient } from "@/lib/supabase/server";
import { UpgradeButton } from "@/components/billing/upgrade-button";

export const metadata = { title: "Tarifs" };

export default async function PricingPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  return (
    <div className="min-h-screen bg-surface-subtle">
      <header className="border-b border-navy-100 bg-white">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
          <Link href="/" className="flex items-center gap-2 font-semibold text-navy-950">
            <Rocket className="h-5 w-5 text-navy-700" />
            LaunchPilot
          </Link>
          <Link href={user ? "/dashboard" : "/login"}>
            <Button size="sm" variant="secondary">
              {user ? "Mon dashboard" : "Connexion"}
            </Button>
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-16">
        <h1 className="text-center text-4xl font-bold text-navy-950">
          Choisissez votre plan
        </h1>
        <p className="mx-auto mt-3 max-w-xl text-center text-navy-600">
          Commencez gratuitement, passez au niveau supérieur quand votre
          lancement décolle. Sans engagement, annulable à tout moment.
        </p>

        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {Object.values(PLANS).map((plan) => {
            const highlighted = plan.id === "pro";
            return (
              <div
                key={plan.id}
                className={`relative rounded-xl border bg-white p-8 shadow-card ${
                  highlighted ? "border-navy-700 ring-2 ring-navy-700" : "border-navy-100"
                }`}
              >
                {highlighted && (
                  <Badge variant="navy" className="absolute -top-3 left-1/2 -translate-x-1/2">
                    Populaire
                  </Badge>
                )}
                <h2 className="text-lg font-semibold text-navy-950">{plan.name}</h2>
                <div className="mt-3 text-4xl font-bold text-navy-950">
                  {plan.price}€
                  <span className="text-base font-normal text-navy-400">/mois</span>
                </div>
                <ul className="mt-6 space-y-3">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2 text-sm text-navy-700">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-navy-600" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <div className="mt-8">
                  {plan.id === "free" ? (
                    <Link href={user ? "/dashboard" : "/signup"} className="block">
                      <Button variant="secondary" className="w-full">
                        {user ? "Plan actuel" : "Commencer gratuitement"}
                      </Button>
                    </Link>
                  ) : (
                    <UpgradeButton
                      plan={plan.id}
                      isLoggedIn={!!user}
                      highlighted={highlighted}
                    />
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <p className="mt-10 text-center text-sm text-navy-400">
          Paiement sécurisé par Stripe · TVA incluse · Annulation en un clic
          depuis votre espace.
        </p>
      </main>
    </div>
  );
}
