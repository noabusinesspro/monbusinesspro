export interface MilestoneTemplate {
  offset_days: number;
  title: string;
  actions: string[];
}

/** Calendrier de lancement standard : J-30 → J+7. */
export const MILESTONE_TEMPLATES: MilestoneTemplate[] = [
  {
    offset_days: -30,
    title: "J-30 — Fondations",
    actions: [
      "Finaliser le positionnement et la proposition de valeur",
      "Mettre la landing page en ligne avec capture email",
      "Commencer à documenter le projet en public",
    ],
  },
  {
    offset_days: -15,
    title: "J-15 — Construire l'audience",
    actions: [
      "Publier 3 contenus sur le problème que vous résolvez",
      "Ouvrir la liste d'attente et viser 100 inscrits",
      "Contacter les partenaires et communautés ciblés",
    ],
  },
  {
    offset_days: -7,
    title: "J-7 — Teasing",
    actions: [
      "Annoncer la date de lancement sur tous les canaux",
      "Envoyer l'email de teasing à la liste d'attente",
      "Finaliser les visuels et le tunnel de paiement",
    ],
  },
  {
    offset_days: -3,
    title: "J-3 — Derniers réglages",
    actions: [
      "Tester le parcours complet (inscription → paiement)",
      "Préparer tous les posts du jour J (programmés)",
      "Briefer les soutiens (amis, communauté, affiliés)",
    ],
  },
  {
    offset_days: -1,
    title: "J-1 — Veille de lancement",
    actions: [
      "Envoyer l'email « c'est demain » à la liste",
      "Vérifier analytics, paiement et page de vente",
      "Préparer la journée : planning heure par heure",
    ],
  },
  {
    offset_days: 0,
    title: "Jour J — Lancement 🚀",
    actions: [
      "Publier l'annonce sur tous les canaux dès le matin",
      "Envoyer l'email de lancement avec l'offre",
      "Répondre à chaque commentaire et message toute la journée",
      "Partager les premiers résultats en fin de journée",
    ],
  },
  {
    offset_days: 7,
    title: "J+7 — Bilan & relance",
    actions: [
      "Envoyer l'email « dernière chance » si offre limitée",
      "Publier le bilan chiffré du lancement",
      "Collecter les retours et planifier les 30 prochains jours",
    ],
  },
];
