import type { ProjectType } from "@/types/database";

export interface ProjectTypeMeta {
  id: ProjectType;
  label: string;
  emoji: string;
  description: string;
}

export const PROJECT_TYPES: ProjectTypeMeta[] = [
  {
    id: "saas",
    label: "SaaS",
    emoji: "⚡",
    description: "Logiciel en ligne avec abonnement",
  },
  {
    id: "application",
    label: "Application",
    emoji: "📱",
    description: "App mobile ou desktop",
  },
  {
    id: "ebook",
    label: "Ebook",
    emoji: "📘",
    description: "Livre numérique ou guide payant",
  },
  {
    id: "formation",
    label: "Formation",
    emoji: "🎓",
    description: "Cours en ligne ou cohorte",
  },
  {
    id: "newsletter",
    label: "Newsletter",
    emoji: "✉️",
    description: "Publication récurrente par email",
  },
  {
    id: "template",
    label: "Template",
    emoji: "🧩",
    description: "Template Notion, Figma, code…",
  },
  {
    id: "agence",
    label: "Agence",
    emoji: "🏢",
    description: "Offre de services productisée",
  },
  {
    id: "coaching",
    label: "Coaching",
    emoji: "🎯",
    description: "Accompagnement individuel ou groupe",
  },
];

export function projectTypeMeta(type: ProjectType): ProjectTypeMeta {
  return PROJECT_TYPES.find((t) => t.id === type) ?? PROJECT_TYPES[0];
}
