import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { Project } from "@/types/database";

/** Charge un projet de l'utilisateur courant (RLS), sinon 404. */
export async function getProjectOr404(id: string): Promise<Project> {
  const supabase = await createClient();
  const { data: project } = await supabase
    .from("projects")
    .select("*")
    .eq("id", id)
    .single<Project>();

  if (!project) notFound();
  return project;
}
