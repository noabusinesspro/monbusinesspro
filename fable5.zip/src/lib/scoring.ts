import type { ChecklistCategory, ChecklistItem } from "@/types/database";

export const CATEGORY_LABELS: Record<ChecklistCategory, string> = {
  branding: "Branding",
  landing_page: "Landing page",
  seo: "SEO",
  social: "Réseaux sociaux",
  email: "Email marketing",
  acquisition: "Acquisition",
  launch: "Lancement",
  post_launch: "Post-lancement",
};

export const CATEGORY_ORDER: ChecklistCategory[] = [
  "branding",
  "landing_page",
  "seo",
  "social",
  "email",
  "acquisition",
  "launch",
  "post_launch",
];

export interface CategoryScore {
  category: ChecklistCategory;
  label: string;
  /** Score sur 20, pondéré par le poids de chaque tâche. */
  score: number;
  done: number;
  total: number;
}

export interface ReadinessScore {
  /** Score global sur 100 (moyenne des catégories ramenée sur 100). */
  global: number;
  categories: CategoryScore[];
  doneCount: number;
  totalCount: number;
}

/**
 * Score de préparation : chaque catégorie vaut 20 points, répartis
 * au prorata du poids des tâches cochées. Le score global est la
 * moyenne des catégories présentes, ramenée sur 100.
 */
export function computeReadiness(items: ChecklistItem[]): ReadinessScore {
  const categories: CategoryScore[] = [];

  for (const category of CATEGORY_ORDER) {
    const catItems = items.filter((i) => i.category === category);
    if (catItems.length === 0) continue;

    const totalWeight = catItems.reduce((s, i) => s + i.weight, 0);
    const doneWeight = catItems
      .filter((i) => i.is_done)
      .reduce((s, i) => s + i.weight, 0);

    categories.push({
      category,
      label: CATEGORY_LABELS[category],
      score: totalWeight === 0 ? 0 : Math.round((doneWeight / totalWeight) * 20),
      done: catItems.filter((i) => i.is_done).length,
      total: catItems.length,
    });
  }

  const global =
    categories.length === 0
      ? 0
      : Math.round(
          (categories.reduce((s, c) => s + c.score, 0) /
            (categories.length * 20)) *
            100
        );

  return {
    global,
    categories,
    doneCount: items.filter((i) => i.is_done).length,
    totalCount: items.length,
  };
}
