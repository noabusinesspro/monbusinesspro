import { createAdminClient } from "@/lib/supabase/server";
import { getPlan } from "@/lib/plans";
import type { PlanType } from "@/types/database";

/**
 * Vérifie le quota mensuel de générations IA pour un utilisateur.
 * Retourne null si OK, sinon un message d'erreur.
 */
export async function checkAiQuota(
  userId: string,
  plan: PlanType
): Promise<string | null> {
  const limit = getPlan(plan).aiGenerationsPerMonth;
  if (limit === Infinity) return null;

  const admin = createAdminClient();
  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);

  const { count, error } = await admin
    .from("ai_usage")
    .select("id", { count: "exact", head: true })
    .eq("user_id", userId)
    .gte("created_at", monthStart.toISOString());

  if (error) throw error;

  if ((count ?? 0) >= limit) {
    return `Quota IA atteint (${limit} générations/mois sur votre plan). Passez au plan supérieur pour continuer.`;
  }
  return null;
}

export async function recordAiUsage(userId: string, kind: string) {
  const admin = createAdminClient();
  await admin.from("ai_usage").insert({ user_id: userId, kind });
}
