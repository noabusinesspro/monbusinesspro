import type { PlanType } from "@/types/database";

export interface PlanConfig {
  id: PlanType;
  name: string;
  price: number; // €/mois
  maxProjects: number; // Infinity = illimité
  aiGenerationsPerMonth: number;
  features: string[];
  stripePriceEnv?: string;
}

export const PLANS: Record<PlanType, PlanConfig> = {
  free: {
    id: "free",
    name: "Gratuit",
    price: 0,
    maxProjects: 1,
    aiGenerationsPerMonth: 10,
    features: [
      "1 projet de lancement",
      "10 générations IA / mois",
      "Checklist intelligente",
      "Calendrier de lancement",
      "Score de préparation",
    ],
  },
  pro: {
    id: "pro",
    name: "Pro",
    price: 19,
    maxProjects: 5,
    aiGenerationsPerMonth: 200,
    features: [
      "5 projets de lancement",
      "200 générations IA / mois",
      "Tous les templates",
      "Générateur de contenu complet",
      "Historique des contenus",
      "Support prioritaire",
    ],
    stripePriceEnv: "STRIPE_PRICE_PRO",
  },
  unlimited: {
    id: "unlimited",
    name: "Unlimited",
    price: 49,
    maxProjects: Infinity,
    aiGenerationsPerMonth: Infinity,
    features: [
      "Projets illimités",
      "Générations IA illimitées",
      "Tous les templates",
      "Accès anticipé aux nouveautés",
      "Support dédié",
    ],
    stripePriceEnv: "STRIPE_PRICE_UNLIMITED",
  },
};

export function getPlan(plan: PlanType): PlanConfig {
  return PLANS[plan] ?? PLANS.free;
}

export function getStripePriceId(plan: PlanType): string | null {
  const env = PLANS[plan]?.stripePriceEnv;
  return env ? (process.env[env] ?? null) : null;
}

export function planFromPriceId(priceId: string): PlanType | null {
  if (priceId === process.env.STRIPE_PRICE_PRO) return "pro";
  if (priceId === process.env.STRIPE_PRICE_UNLIMITED) return "unlimited";
  return null;
}
