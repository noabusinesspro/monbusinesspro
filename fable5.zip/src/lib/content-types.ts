import type { ContentType } from "@/types/database";

export interface ContentTypeMeta {
  id: ContentType;
  label: string;
  emoji: string;
  description: string;
  /** Instructions de format passées à l'IA. */
  format: string;
}

export const CONTENT_TYPES: ContentTypeMeta[] = [
  {
    id: "linkedin_post",
    label: "Post LinkedIn",
    emoji: "💼",
    description: "Post engageant avec accroche forte",
    format:
      "Un post LinkedIn de 150-250 mots. Accroche percutante sur la première ligne, paragraphes courts, storytelling, appel à l'action final. Pas de hashtags excessifs (3 max).",
  },
  {
    id: "twitter_post",
    label: "Post X / Twitter",
    emoji: "🐦",
    description: "Thread ou post court percutant",
    format:
      "Un thread X de 5-7 tweets. Premier tweet = accroche qui donne envie de lire la suite. Chaque tweet < 280 caractères. Dernier tweet = appel à l'action avec lien.",
  },
  {
    id: "launch_email",
    label: "Email de lancement",
    emoji: "📧",
    description: "Email d'annonce à votre liste",
    format:
      "Un email de lancement : objet (et un objet alternatif), pré-header, corps de 200-300 mots orienté bénéfices, un seul appel à l'action clair, PS avec urgence ou bonus.",
  },
  {
    id: "community_message",
    label: "Message communauté",
    emoji: "👥",
    description: "Pour Slack, Discord, Reddit…",
    format:
      "Un message pour une communauté en ligne (Slack/Discord/Reddit). Ton authentique, pas promotionnel : contexte personnel, le problème résolu, demande de feedback. 100-150 mots.",
  },
  {
    id: "product_announcement",
    label: "Annonce produit",
    emoji: "📣",
    description: "Annonce officielle réutilisable",
    format:
      "Une annonce produit officielle : titre, sous-titre, 3 bénéfices clés avec puces, citation du fondateur, appel à l'action. Réutilisable en changelog ou communiqué.",
  },
  {
    id: "product_hunt",
    label: "Product Hunt",
    emoji: "🚀",
    description: "Tagline + description + premier commentaire",
    format:
      "Un kit Product Hunt : tagline (60 caractères max), description (260 caractères max), et premier commentaire du maker (150-200 mots, ton personnel, contexte de création, ce qui rend le produit unique).",
  },
];

export function contentTypeMeta(id: ContentType): ContentTypeMeta {
  return CONTENT_TYPES.find((c) => c.id === id) ?? CONTENT_TYPES[0];
}
