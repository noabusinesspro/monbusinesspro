import type { ChecklistCategory, ProjectType } from "@/types/database";

export interface ChecklistTemplateItem {
  category: ChecklistCategory;
  title: string;
  description?: string;
  weight?: number; // 1–5, défaut 1
  /** Si défini, l'item n'est inclus que pour ces types de projet. */
  only?: ProjectType[];
  /** Si défini, l'item est exclu pour ces types de projet. */
  except?: ProjectType[];
}

/**
 * Checklist de base, adaptée au type de projet via `only` / `except`.
 * Les poids reflètent l'impact de la tâche sur la réussite du lancement.
 */
const BASE_CHECKLIST: ChecklistTemplateItem[] = [
  // --- Branding ---
  { category: "branding", title: "Choisir le nom et vérifier sa disponibilité", weight: 3 },
  { category: "branding", title: "Créer le logo et la palette de couleurs", weight: 2 },
  { category: "branding", title: "Définir le ton et la voix de marque", weight: 2 },
  { category: "branding", title: "Préparer les visuels réseaux sociaux (bannières, avatar)", weight: 1 },

  // --- Landing page ---
  { category: "landing_page", title: "Rédiger le titre et la proposition de valeur", weight: 4 },
  { category: "landing_page", title: "Ajouter des preuves sociales (témoignages, logos)", weight: 3 },
  { category: "landing_page", title: "Mettre en place le formulaire de capture email", weight: 3 },
  { category: "landing_page", title: "Optimiser la vitesse et le mobile", weight: 2 },
  { category: "landing_page", title: "Créer une démo ou des captures du produit", weight: 3, only: ["saas", "application", "template"] },
  { category: "landing_page", title: "Publier un extrait gratuit (chapitre, leçon)", weight: 3, only: ["ebook", "formation"] },

  // --- SEO ---
  { category: "seo", title: "Rechercher les mots-clés principaux", weight: 2 },
  { category: "seo", title: "Optimiser les balises title et meta description", weight: 2 },
  { category: "seo", title: "Configurer Google Search Console et le sitemap", weight: 1 },
  { category: "seo", title: "Publier 2-3 articles de fond avant le lancement", weight: 2, except: ["template"] },

  // --- Réseaux sociaux ---
  { category: "social", title: "Créer / optimiser les profils LinkedIn et X", weight: 2 },
  { category: "social", title: "Planifier la séquence build in public (J-30 → J)", weight: 3 },
  { category: "social", title: "Identifier 10 communautés où partager le lancement", weight: 3 },
  { category: "social", title: "Préparer les visuels et vidéos de lancement", weight: 2 },

  // --- Email marketing ---
  { category: "email", title: "Choisir et configurer l'outil d'emailing", weight: 2 },
  { category: "email", title: "Créer la séquence de bienvenue", weight: 2 },
  { category: "email", title: "Rédiger la séquence de lancement (teasing, ouverture, dernière chance)", weight: 4 },
  { category: "email", title: "Construire une liste d'attente avant le jour J", weight: 4 },

  // --- Acquisition ---
  { category: "acquisition", title: "Définir le canal d'acquisition prioritaire", weight: 4 },
  { category: "acquisition", title: "Préparer la page Product Hunt", weight: 3, only: ["saas", "application", "template"] },
  { category: "acquisition", title: "Contacter 10 partenaires ou affiliés potentiels", weight: 2 },
  { category: "acquisition", title: "Préparer une offre de lancement (réduction, bonus)", weight: 3 },
  { category: "acquisition", title: "Identifier des newsletters / podcasts pour des mentions", weight: 2, only: ["ebook", "formation", "newsletter", "coaching"] },

  // --- Lancement ---
  { category: "launch", title: "Tester le tunnel de paiement de bout en bout", weight: 5, except: ["newsletter"] },
  { category: "launch", title: "Vérifier l'analytics et le tracking des conversions", weight: 2 },
  { category: "launch", title: "Publier l'annonce sur tous les canaux le jour J", weight: 4 },
  { category: "launch", title: "Répondre aux commentaires et questions en continu", weight: 3 },

  // --- Post-lancement ---
  { category: "post_launch", title: "Envoyer l'email de remerciement + récap", weight: 2 },
  { category: "post_launch", title: "Collecter les premiers retours utilisateurs", weight: 3 },
  { category: "post_launch", title: "Publier le bilan du lancement (métriques, leçons)", weight: 2 },
  { category: "post_launch", title: "Planifier la roadmap des 30 prochains jours", weight: 2 },
];

export function checklistForType(type: ProjectType): ChecklistTemplateItem[] {
  return BASE_CHECKLIST.filter((item) => {
    if (item.only && !item.only.includes(type)) return false;
    if (item.except && item.except.includes(type)) return false;
    return true;
  });
}
