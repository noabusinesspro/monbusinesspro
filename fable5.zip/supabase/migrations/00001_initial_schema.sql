-- ============================================================
-- LaunchPilot — Schéma initial Supabase
-- ============================================================
-- Tables : profiles, projects, checklist_items, milestones,
--          generated_content, ai_usage
-- Sécurité : RLS activé partout, chaque utilisateur ne voit
--            que ses propres données.
-- ============================================================

-- ---------- Types énumérés ----------

create type project_type as enum (
  'saas', 'ebook', 'formation', 'newsletter', 'template', 'application',
  'agence', 'coaching'
);

create type plan_type as enum ('free', 'pro', 'unlimited');

create type checklist_category as enum (
  'branding', 'landing_page', 'seo', 'social', 'email',
  'acquisition', 'launch', 'post_launch'
);

create type content_type as enum (
  'linkedin_post', 'twitter_post', 'launch_email', 'community_message',
  'product_announcement', 'product_hunt'
);

-- ---------- profiles ----------
-- Étend auth.users (1:1). Créé automatiquement par trigger.

create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text not null,
  full_name text,
  avatar_url text,
  plan plan_type not null default 'free',
  stripe_customer_id text unique,
  stripe_subscription_id text unique,
  plan_renews_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "profiles_select_own" on public.profiles
  for select using (auth.uid() = id);
create policy "profiles_update_own" on public.profiles
  for update using (auth.uid() = id);

-- Création automatique du profil à l'inscription (email ou Google).
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name, avatar_url)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name'),
    new.raw_user_meta_data ->> 'avatar_url'
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- projects ----------

create table public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  name text not null check (char_length(name) between 1 and 120),
  type project_type not null,
  description text,
  launch_date date,
  -- Résultat de l'assistant IA (positionnement, pitch, FAQ, CTA…)
  positioning jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index projects_user_id_idx on public.projects (user_id);

alter table public.projects enable row level security;

create policy "projects_all_own" on public.projects
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ---------- checklist_items ----------
-- Générés depuis les templates à la création du projet,
-- adaptés au type de projet. Le scoring est calculé dessus.

create table public.checklist_items (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects (id) on delete cascade,
  category checklist_category not null,
  title text not null,
  description text,
  weight smallint not null default 1 check (weight between 1 and 5),
  is_done boolean not null default false,
  sort_order smallint not null default 0,
  created_at timestamptz not null default now()
);

create index checklist_items_project_idx on public.checklist_items (project_id);

alter table public.checklist_items enable row level security;

create policy "checklist_all_own" on public.checklist_items
  for all using (
    exists (
      select 1 from public.projects p
      where p.id = project_id and p.user_id = auth.uid()
    )
  ) with check (
    exists (
      select 1 from public.projects p
      where p.id = project_id and p.user_id = auth.uid()
    )
  );

-- ---------- milestones ----------
-- Calendrier de lancement : J-30 → J+7, avec actions recommandées.

create table public.milestones (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects (id) on delete cascade,
  offset_days smallint not null, -- -30, -15, -7, -3, -1, 0, 7
  title text not null,
  actions jsonb not null default '[]', -- [{ "label": "...", "done": false }]
  created_at timestamptz not null default now(),
  unique (project_id, offset_days)
);

create index milestones_project_idx on public.milestones (project_id);

alter table public.milestones enable row level security;

create policy "milestones_all_own" on public.milestones
  for all using (
    exists (
      select 1 from public.projects p
      where p.id = project_id and p.user_id = auth.uid()
    )
  ) with check (
    exists (
      select 1 from public.projects p
      where p.id = project_id and p.user_id = auth.uid()
    )
  );

-- ---------- generated_content ----------
-- Historique des contenus générés par l'IA.

create table public.generated_content (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects (id) on delete cascade,
  type content_type not null,
  content text not null,
  created_at timestamptz not null default now()
);

create index generated_content_project_idx on public.generated_content (project_id);

alter table public.generated_content enable row level security;

create policy "content_all_own" on public.generated_content
  for all using (
    exists (
      select 1 from public.projects p
      where p.id = project_id and p.user_id = auth.uid()
    )
  ) with check (
    exists (
      select 1 from public.projects p
      where p.id = project_id and p.user_id = auth.uid()
    )
  );

-- ---------- ai_usage ----------
-- Compteur de générations IA pour appliquer les quotas par plan.
-- Écrit uniquement côté serveur (service role) — pas de policy insert.

create table public.ai_usage (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  kind text not null, -- 'positioning' | 'content'
  created_at timestamptz not null default now()
);

create index ai_usage_user_month_idx on public.ai_usage (user_id, created_at);

alter table public.ai_usage enable row level security;

create policy "ai_usage_select_own" on public.ai_usage
  for select using (auth.uid() = user_id);

-- ---------- updated_at automatique ----------

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();
create trigger projects_updated_at before update on public.projects
  for each row execute function public.set_updated_at();
