# Design System — LaunchPilot

Inspiration : **Linear** (densité, précision), **Notion** (sobriété, lisibilité), **Stripe** (confiance, hiérarchie typographique). Dominantes : **bleu marine** et **blanc**.

## Couleurs

Palette `navy` définie dans `tailwind.config.ts` :

| Token      | Hex       | Usage |
|------------|-----------|-------|
| `navy-950` | `#0e1830` | Texte principal, fonds sombres (CTA final) |
| `navy-900` | `#1b2c4e` | Boutons primaires, éléments actifs |
| `navy-700` | `#264478` | Icônes de marque, barres de progression |
| `navy-600` | `#2d5494` | Texte secondaire accentué |
| `navy-500` | `#3d6cb0` | Texte tertiaire |
| `navy-400` | `#5f8ac5` | Texte discret (métadonnées) |
| `navy-200` | `#bdd0ea` | Bordures d'inputs |
| `navy-100` | `#dce6f5` | Bordures de cartes, séparateurs, fonds de progress |
| `navy-50`  | `#f0f4fa` | Fonds hover, badges, fonds sélectionnés |
| `surface-subtle` | `#f8fafc` | Fond de l'app (espace connecté) |
| Blanc      | `#ffffff` | Fond des cartes et pages publiques |

Couleurs sémantiques (Tailwind standard) : `emerald` = succès/terminé, `amber` = avertissement/retard/priorité, `red` = erreur/danger.

**Règle** : la couleur porte du sens, jamais de la décoration. Un seul accent fort par écran (le bouton primaire navy-900).

## Typographie

- Police : **Inter** (via `next/font`), antialiased.
- Échelle :
  - `text-5xl/6xl font-bold tracking-tight` — héros landing
  - `text-2xl font-bold` — titres de page
  - `text-base font-semibold` — titres de carte
  - `text-sm` — corps de texte applicatif (défaut)
  - `text-xs` — métadonnées, labels secondaires

## Espacements & formes

- Rayons : `rounded-lg` (8px) pour les contrôles, `rounded-xl` (14px) pour les cartes, `rounded-full` pour badges et pills.
- Ombres : `shadow-card` (repos) → `shadow-card-hover` (survol). Jamais d'ombres dures.
- Conteneurs : `max-w-6xl` pages publiques, `max-w-5xl` app, `max-w-2xl` formulaires.

## Composants (`src/components/ui/`)

| Composant | Variantes | Notes |
|-----------|-----------|-------|
| `Button`  | `primary` `secondary` `ghost` `danger` × `sm` `md` `lg` | État `loading` avec spinner intégré |
| `Card` + `CardHeader/Title/Description/Content` | — | Bordure navy-100 + shadow-card |
| `Badge`   | `default` `success` `warning` `navy` | Pill, texte xs |
| `Input` / `Textarea` / `Label` | — | Focus : ring navy-100 + bordure navy-500 |
| `Progress` | — | Barre 8px, navy-700 sur navy-100 |
| `ScoreRing` | — | Anneau SVG du score /100, animé |

## Interactions

- Transitions : `transition-colors` (150ms) partout ; `duration-500/700` pour les progressions.
- Apparition de page : `animate-fade-up` (8px, 350ms) — une seule fois par vue, jamais en cascade.
- Mises à jour optimistes sur la checklist et le calendrier (rollback si erreur réseau).
- États vides toujours accompagnés d'une action (« Créer mon premier projet »).

## Voix & ton

- Français, tutoiement évité — vouvoiement chaleureux ("Préparez votre lancement").
- Orienté action : chaque écran indique la prochaine étape.
- Emojis avec parcimonie : marqueurs de catégories de projet et de moments forts (🚀, 🎉) uniquement.
