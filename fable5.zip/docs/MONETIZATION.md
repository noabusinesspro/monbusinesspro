# Plan de monétisation — LaunchPilot

## Modèle : freemium → abonnement SaaS

Le produit accompagne un **moment à forte valeur perçue** (un lancement) : la volonté de payer est maximale dans les 30 jours qui le précèdent. Le plan gratuit fait vivre la valeur complète sur **un** projet ; la montée en gamme est déclenchée par le volume (projets, générations IA), pas par le bridage des fonctionnalités cœur.

## Plans

| | Gratuit | Pro — 19€/mois | Unlimited — 49€/mois |
|---|---|---|---|
| Projets | 1 | 5 | Illimités |
| Générations IA / mois | 10 | 200 | Illimitées |
| Checklist + calendrier + scoring | ✅ | ✅ | ✅ |
| Assistant IA + générateur de contenu | ✅ (quota) | ✅ | ✅ |
| Templates | ✅ | ✅ | ✅ |
| Support | Standard | Prioritaire | Dédié |

**Cibles** : Gratuit = créateur qui teste ; Pro = indépendant/créateur en série (cœur de cible) ; Unlimited = agences, ghost-launchers, créateurs prolifiques.

### Logique de pricing
- 19€ : sous le seuil psychologique des 20€, aligné sur les outils créateurs (Buffer, ConvertKit entrée de gamme). Un seul lancement réussi rembourse des années d'abonnement → argument de vente central.
- 49€ : ancre haute qui rend Pro attractif ; marge confortable sur les coûts IA (gpt-4o-mini ≈ quelques centimes par génération).
- Mensuel sans engagement au MVP ; plan annuel (-20 %) à introduire dès les premiers clients pour lisser le churn saisonnier (on se désabonne après son lancement).

## Mécanique de conversion

1. **Activation** (gratuit) : projet créé + positionnement généré + 5 tâches cochées. Le score de préparation crée l'habitude de revenir.
2. **Murs de conversion naturels** :
   - 2ᵉ projet → upgrade Pro (un créateur lance rarement une seule fois) ;
   - quota IA atteint en pleine préparation → upgrade contextualisé (le message d'erreur propose directement le plan supérieur) ;
   - approche du jour J → besoin maximal de contenus générés.
3. **Implémentation** : limites vérifiées côté serveur (`/api/projects`, `ai-quota.ts`), erreurs 402 avec message d'upgrade, page `/pricing` accessible en un clic.

## Métriques à suivre

| Étape | Métrique | Cible MVP |
|---|---|---|
| Acquisition | Visiteurs → inscription | 5 % |
| Activation | Inscription → 1er positionnement généré | 40 % |
| Conversion | Gratuit → payant (30 j) | 4–6 % |
| Rétention | Churn mensuel Pro | < 8 % |
| Revenu | MRR, ARPU | 1 000 € MRR à M+3 |

## Leviers de croissance

- **Le produit comme démo** : lancer LaunchPilot **avec** LaunchPilot, en public (Product Hunt, X, LinkedIn) — crédibilité maximale.
- **Boucle virale légère** : badge « Préparé avec LaunchPilot » optionnel sur les pages de lancement des utilisateurs.
- **SEO programmatique** : pages « Checklist de lancement [SaaS/ebook/formation…] » générées depuis les templates existants.
- **Affiliation 30 %** récurrente pour les créateurs de contenu business/indie-hacking.

## Évolutions de revenu (post-MVP)

- Plan annuel (-20 %).
- Add-on « Lancement accompagné » (revue humaine du plan, one-shot 149€).
- Tier équipe/agence avec projets partagés et marque blanche.
