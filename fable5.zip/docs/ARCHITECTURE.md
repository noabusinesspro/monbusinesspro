# Architecture — LaunchPilot

## Vue d'ensemble

LaunchPilot est une application **Next.js 15 (App Router)** full-stack déployable sur Vercel, avec Supabase comme backend (Postgres + Auth), OpenAI pour l'IA et Stripe pour les abonnements.

```
┌─────────────────────────────────────────────────────────┐
│                     Next.js (Vercel)                     │
│                                                          │
│  Pages (RSC)            API Routes          Middleware   │
│  ├─ / (landing)         ├─ /api/projects    └─ session   │
│  ├─ /pricing            ├─ /api/ai/*           refresh + │
│  ├─ /login /signup      ├─ /api/stripe/*       guard     │
│  ├─ /dashboard          │                                │
│  ├─ /projects/[id]/*    │                                │
│  ├─ /templates          │                                │
│  └─ /settings/billing   │                                │
└──────────┬──────────────────────┬──────────────┬─────────┘
           │                      │              │
     ┌─────▼─────┐         ┌──────▼──────┐ ┌─────▼─────┐
     │ Supabase  │         │   OpenAI    │ │  Stripe   │
     │ Postgres  │         │ gpt-4o-mini │ │ Checkout  │
     │ Auth+RLS  │         │             │ │ + Webhook │
     └───────────┘         └─────────────┘ └───────────┘
```

## Principes

1. **Server Components par défaut** : toutes les lectures de données se font côté serveur via le client Supabase SSR (`src/lib/supabase/server.ts`). Les composants clients (`"use client"`) ne servent qu'à l'interactivité (formulaires, toggles, génération IA).
2. **RLS comme couche de sécurité principale** : chaque table a des policies `auth.uid()`. Même un bug applicatif ne peut pas exposer les données d'un autre utilisateur. Les mutations simples (cocher une tâche) passent directement par le client Supabase navigateur, protégées par RLS.
3. **API routes pour la logique métier** : tout ce qui touche aux quotas, à l'IA ou à Stripe passe par une API route serveur (validation Zod, vérification de plan, appels aux secrets).
4. **Stripe = source de vérité de l'abonnement** : le webhook (`/api/stripe/webhook`) synchronise `profiles.plan`. L'app ne modifie jamais le plan directement.
5. **Templates en code, données en base** : checklists et calendriers types vivent dans `src/lib/*-templates.ts` (versionnés, faciles à faire évoluer) et sont **matérialisés en base à la création du projet** — l'utilisateur peut ensuite les modifier sans affecter les templates.

## Arborescence

```
src/
├── app/
│   ├── page.tsx                      # Landing
│   ├── pricing/page.tsx              # Tarifs publics
│   ├── (auth)/                       # login, signup (layout centré)
│   ├── auth/callback/route.ts        # Échange code OAuth/email → session
│   ├── (app)/                        # Espace connecté (layout sidebar)
│   │   ├── dashboard/                # Liste des projets + progression
│   │   ├── projects/new/             # Création (checklist+calendrier auto)
│   │   ├── projects/[id]/            # Vue d'ensemble (scoring)
│   │   │   ├── assistant/            # Assistant IA (positionnement)
│   │   │   ├── content/              # Générateur de contenu
│   │   │   ├── checklist/            # Checklist par catégorie
│   │   │   └── calendar/             # Timeline J-30 → J+7
│   │   ├── templates/                # Bibliothèque de templates
│   │   └── settings/billing/         # Plan, portail Stripe
│   └── api/
│       ├── projects/route.ts         # POST : création + provisioning
│       ├── ai/positioning/route.ts   # POST : génération positionnement
│       ├── ai/content/route.ts       # POST : génération contenu
│       └── stripe/
│           ├── checkout/route.ts     # POST : session Checkout
│           ├── portal/route.ts       # POST : portail client
│           └── webhook/route.ts      # POST : sync abonnements
├── components/
│   ├── ui/                           # Design system (button, card, …)
│   ├── app/sidebar.tsx
│   ├── auth/auth-form.tsx
│   ├── billing/
│   └── projects/                     # Clients : checklist, calendrier, IA…
├── lib/
│   ├── supabase/{client,server,middleware}.ts
│   ├── plans.ts                      # Plans, limites, mapping Stripe
│   ├── scoring.ts                    # Score de préparation /100
│   ├── checklist-templates.ts        # Checklist adaptative par type
│   ├── calendar-templates.ts         # Jalons J-30 → J+7
│   ├── content-types.ts              # 6 formats de contenu IA
│   ├── ai-quota.ts                   # Quotas IA par plan
│   ├── openai.ts / stripe.ts         # Clients singletons
│   └── utils.ts
├── types/database.ts                 # Types des tables
└── middleware.ts                     # Session + protection des routes
supabase/migrations/                  # Schéma SQL versionné
docs/                                 # Architecture, design, monétisation
```

## Flux utilisateur clés

### Onboarding
1. Inscription (Google OAuth ou email/mot de passe) → trigger Postgres crée le `profile` (plan `free`).
2. Redirection `/dashboard` → état vide → « Créer mon premier projet ».
3. Création du projet : choix du type → l'API provisionne la **checklist adaptée** et les **7 jalons** du calendrier.
4. La vue d'ensemble suggère de lancer l'**assistant IA** en premier (le positionnement alimente ensuite le générateur de contenu).

### Génération IA
```
Client → POST /api/ai/positioning
  ├─ auth (session Supabase)
  ├─ vérif quota mensuel (table ai_usage, par plan)
  ├─ OpenAI (response_format: json_object)
  ├─ persistance dans projects.positioning (jsonb)
  └─ enregistrement ai_usage
```
Le générateur de contenu suit le même flux et injecte le positionnement dans le prompt.

### Abonnement
```
/pricing → POST /api/stripe/checkout → Stripe Checkout
Stripe → POST /api/stripe/webhook (signé)
  ├─ checkout.session.completed   → plan activé
  ├─ customer.subscription.updated → changement de plan
  └─ customer.subscription.deleted → retour à free
→ update profiles.plan (service role)
```

## Sécurité

- RLS sur toutes les tables ; `ai_usage` n'est inscriptible que par le service role.
- Webhook Stripe vérifié par signature, exclu du middleware de session.
- Validation Zod de tous les corps de requête API.
- Redirection post-auth restreinte aux chemins internes (anti open-redirect).
- Secrets uniquement côté serveur (`SUPABASE_SERVICE_ROLE_KEY`, `OPENAI_API_KEY`, `STRIPE_SECRET_KEY`).

## Évolutions prévues (post-MVP)

- Génération en streaming (Server-Sent Events) pour l'assistant.
- Édition des items de checklist (ajout/suppression par l'utilisateur).
- Rappels email (Resend + cron Vercel) aux jalons du calendrier.
- Analytics de lancement (intégration Plausible/PostHog).
- Mode équipe (partage de projet) — table `project_members`.
