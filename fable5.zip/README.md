# 🚀 LaunchPilot

**Le copilote de lancement des créateurs, indépendants et fondateurs.**

LaunchPilot transforme un lancement de produit digital complexe (SaaS, ebook, formation, newsletter, template, application) en un processus guidé étape par étape : positionnement généré par IA, contenus prêts à publier, checklist adaptative, calendrier J-30 → J+7 et score de préparation sur 100.

## Fonctionnalités MVP

- **Dashboard** — tous vos lancements avec progression, date et tâches restantes
- **Assistant IA** — décrivez votre projet, obtenez positionnement, proposition de valeur, pitch, description longue, FAQ et CTA
- **Générateur de contenu** — posts LinkedIn / X, emails de lancement, messages communautés, annonces produit, kit Product Hunt
- **Checklist intelligente** — 8 catégories (branding → post-lancement), adaptée au type de projet
- **Calendrier de lancement** — jalons J-30, J-15, J-7, J-3, J-1, Jour J, J+7 avec actions recommandées
- **Bibliothèque de templates** — SaaS, newsletter, ebook, formation, agence, coaching
- **Scoring** — score de préparation /100, détaillé par catégorie (/20)
- **Auth** — Google OAuth + email/mot de passe (Supabase Auth)
- **Abonnements** — Gratuit / Pro 19€ / Unlimited 49€ (Stripe)

## Stack

Next.js 15 (App Router) · TypeScript · Tailwind CSS · Supabase (Postgres, Auth, RLS) · OpenAI · Stripe

## Démarrage

### 1. Prérequis

- Node.js ≥ 20
- Un projet [Supabase](https://supabase.com), une clé [OpenAI](https://platform.openai.com), un compte [Stripe](https://stripe.com)

### 2. Installation

```bash
npm install
cp .env.example .env.local   # puis remplir les variables
```

### 3. Base de données

Appliquez la migration dans l'éditeur SQL Supabase (ou via la CLI) :

```bash
supabase db push        # ou copier/coller supabase/migrations/00001_initial_schema.sql
```

### 4. Auth Google

Dans Supabase → Authentication → Providers → Google : renseignez le client ID/secret OAuth et ajoutez `https://<votre-domaine>/auth/callback` aux URL de redirection.

### 5. Stripe

1. Créez deux produits récurrents : **Pro 19€/mois** et **Unlimited 49€/mois**.
2. Reportez les `price_...` dans `STRIPE_PRICE_PRO` / `STRIPE_PRICE_UNLIMITED`.
3. Créez un webhook vers `https://<votre-domaine>/api/stripe/webhook` écoutant `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`, et reportez le secret dans `STRIPE_WEBHOOK_SECRET`.

En local : `stripe listen --forward-to localhost:3000/api/stripe/webhook`.

### 6. Lancer

```bash
npm run dev          # http://localhost:3000
npm run typecheck    # vérification TypeScript
npm run build        # build de production
```

## Documentation

- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — architecture, flux utilisateur, sécurité
- [`docs/DESIGN_SYSTEM.md`](docs/DESIGN_SYSTEM.md) — couleurs, typographie, composants
- [`docs/MONETIZATION.md`](docs/MONETIZATION.md) — plans, conversion, métriques
- [`supabase/migrations/`](supabase/migrations/) — schéma SQL versionné

## Déploiement (Vercel)

1. Importez le repo dans Vercel.
2. Renseignez toutes les variables de `.env.example` (avec `NEXT_PUBLIC_APP_URL` = URL de production).
3. Pointez le webhook Stripe et les redirect URL Supabase vers le domaine de production.
